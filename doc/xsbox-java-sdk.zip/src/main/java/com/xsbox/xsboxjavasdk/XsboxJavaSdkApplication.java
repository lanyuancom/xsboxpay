package com.xsbox.xsboxjavasdk;

import java.util.HashMap;
import java.util.Map;

public class XsboxJavaSdkApplication {

    public static void main(String[] args) {
        Map<String,Object> paramMap = new HashMap<String,Object>();
        paramMap.put("appId","应用ID");
        paramMap.put("mchNo","平台商户号");
        paramMap.put("appSecret","应用私钥");
        paramMap.put("mchOrderNo","123223432432");
        paramMap.put("amount","100");//支付金额， 单位：分
        paramMap.put("subject","选填  商品标题");
        paramMap.put("body","选填  商品内容" );
        String url = "https://tiger-f-payment.tiger-payment.com/xsbox-pay/api/pay/subOrder";
        String result = CommonUtil.postUrl(url,paramMap);//表单内容
        System.out.println(result);
    }

}
