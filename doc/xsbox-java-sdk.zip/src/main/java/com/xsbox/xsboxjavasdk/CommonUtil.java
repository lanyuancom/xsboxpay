package com.xsbox.xsboxjavasdk;


import java.io.*;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class CommonUtil {

	/**
	 * 获取远程内容 UTF8编码
	 * 
	 * @param urlStr
	 *            网络地址
	 * @param requestParamsMap
	 *            参数
	 */
	public static String postUrl(String urlStr, Map<String, Object> requestParamsMap) {
		URL url = null;
		String data = null;
		try {
			StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
	        StackTraceElement log = stackTrace[1];
	        String tag = null;
	        for (int i = 1; i < stackTrace.length; i++) {
	            StackTraceElement e = stackTrace[i];
	            if (!e.getClassName().equals(log.getClassName())) {
	                tag = e.getClassName() + "." + e.getMethodName();
	                break;
	            }
	        }
	        if (tag == null) {
	            tag = log.getClassName() + "." + log.getMethodName();
	        }
			// 之前所有的参数只是写入写出流的缓存中并没有发送到服务端，执行下面这句话后表示将参数信息发送到服务端
			// 组织请求参数
			StringBuffer params = new StringBuffer();
			if (null != requestParamsMap) {
				Iterator<Entry<String, Object>> it = requestParamsMap.entrySet().iterator();
				while (it.hasNext()) {
					Entry<String, Object> element = (Entry<String, Object>) it.next();
					params.append(element.getKey());
					params.append("=");
					params.append(element.getValue());
					params.append("&");
				}
				if (params.length() > 0) {
					params.deleteCharAt(params.length() - 1);
				}
			}
			url = new URL(urlStr);
			HttpURLConnection httpsURLConnection = (HttpURLConnection) url.openConnection();
			// 2、设置属性
			// post请求必须设置的两个
			httpsURLConnection.setDoInput(true);
			httpsURLConnection.setDoOutput(true);
			// 设置属性
			httpsURLConnection.setUseCaches(false);
			httpsURLConnection.setRequestMethod("POST");
			httpsURLConnection.setRequestProperty("accept", "*/*");
			httpsURLConnection.setRequestProperty("connection", "Keep-Alive");
			httpsURLConnection.setRequestProperty("Content-Length", String.valueOf(params.length()));
			httpsURLConnection.setRequestProperty("Accept-Charset", "UTF-8");
			httpsURLConnection.setRequestProperty("contentType", "UTF-8");
			httpsURLConnection.setRequestProperty("user-agent",
					"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)");
			httpsURLConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
			httpsURLConnection.setConnectTimeout(5 * 1000);
			// 如果使用URLconnection既要读取输入流 又要传参数 那么一定要先使用输出流 在使用输入流
			// getOutputStream 中包含了connect 也就是说使用了getoutputStream的时候connect可以不写
			OutputStream os = httpsURLConnection.getOutputStream();
			// 设置编码 防止到服务端出现中文乱码
			OutputStreamWriter ow = new OutputStreamWriter(os, "UTF-8");
			PrintWriter printWriter = new PrintWriter(ow, true);
			// 发送请求参数
			printWriter.write(params.toString());
			// flush输出流的缓冲
			printWriter.flush();
			if (httpsURLConnection.getResponseCode() == 200) {
				// 通过输入流获取网络图片
				InputStream inputStream = httpsURLConnection.getInputStream();
				data = readHtml(inputStream, "UTF-8");
				inputStream.close();
			}else{
			}
		} catch (Exception e) {
			e.printStackTrace();
			data = null;
		}
		return data;
	}

	/**
	 * 获取远程内容 UTF8编码
	 * 
	 * @param urlStr
	 *            网络地址
	 * @param requestParamsMap
	 *            参数
	 * @param headers
	 *            headers参数
	 */
	public static String postUrl(String urlStr, Map<String, Object> requestParamsMap,
			Map<String, String> headers) {
		URL url = null;
		try {
			// 之前所有的参数只是写入写出流的缓存中并没有发送到服务端，执行下面这句话后表示将参数信息发送到服务端
			// 组织请求参数
			StringBuffer params = new StringBuffer();
			if (null != requestParamsMap) {
				Iterator<Entry<String, Object>> it = requestParamsMap.entrySet().iterator();
				while (it.hasNext()) {
					Entry<String, Object> element = (Entry<String, Object>) it.next();
					params.append(element.getKey());
					params.append("=");
					params.append(element.getValue());
					params.append("&");
				}
				if (params.length() > 0) {
					params.deleteCharAt(params.length() - 1);
				}
			}
			url = new URL(urlStr);
			HttpURLConnection httpsURLConnection = (HttpURLConnection) url.openConnection();
			// 2、设置属性
			// post请求必须设置的两个
			httpsURLConnection.setDoInput(true);
			httpsURLConnection.setDoOutput(true);
			// 设置属性
			httpsURLConnection.setUseCaches(false);
			httpsURLConnection.setRequestMethod("POST");
			// 设置通用的请求属性
			if (null != headers && headers.size() > 0)
				for (Entry<String, String> entry : headers.entrySet()) {
					String key = entry.getKey();
					httpsURLConnection.setRequestProperty(key, entry.getValue());
				}
			httpsURLConnection.setRequestProperty("accept", "*/*");
			httpsURLConnection.setRequestProperty("connection", "Keep-Alive");
			httpsURLConnection.setRequestProperty("Content-Length", String.valueOf(params.length()));
			httpsURLConnection.setRequestProperty("Accept-Charset", "UTF-8");
			httpsURLConnection.setRequestProperty("contentType", "UTF-8");
			httpsURLConnection.setRequestProperty("user-agent",
					"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)");
			httpsURLConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
			httpsURLConnection.setConnectTimeout(5 * 1000);
			// 如果使用URLconnection既要读取输入流 又要传参数 那么一定要先使用输出流 在使用输入流
			// getOutputStream 中包含了connect 也就是说使用了getoutputStream的时候connect可以不写
			OutputStream os = httpsURLConnection.getOutputStream();
			// 设置编码 防止到服务端出现中文乱码
			OutputStreamWriter ow = new OutputStreamWriter(os, "UTF-8");
			PrintWriter printWriter = new PrintWriter(ow, true);
			// 发送请求参数
			printWriter.write(params.toString());
			// flush输出流的缓冲
			printWriter.flush();
			if (httpsURLConnection.getResponseCode() == 200) {
				// 通过输入流获取网络图片
				InputStream inputStream = httpsURLConnection.getInputStream();
				String data = readHtml(inputStream, "UTF-8");
				inputStream.close();
				return data;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return "异常：" + e.getMessage();
		}
		return null;
	}



	/**
	 * @param inputStream
	 * @param uncode
	 *            编码 GBK 或 UTF-8
	 * @return
	 * @throws Exception
	 */
	public static String readHtml(InputStream inputStream, String uncode) throws Exception {
		InputStreamReader input = new InputStreamReader(inputStream, uncode);
		BufferedReader bufReader = new BufferedReader(input);
		String line = "";
		StringBuilder contentBuf = new StringBuilder();
		while ((line = bufReader.readLine()) != null) {
			contentBuf.append(line);
		}
		return contentBuf.toString();
	}

	/**
	 * 
	 * @return 返回资源的二进制数据 @
	 */
	public static byte[] readInputStream(InputStream inputStream) {

		// 定义一个输出流向内存输出数据
		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
		// 定义一个缓冲区
		byte[] buffer = new byte[1024];
		// 读取数据长度
		int len = 0;
		// 当取得完数据后会返回一个-1
		try {
			while ((len = inputStream.read(buffer)) != -1) {
				// 把缓冲区的数据 写到输出流里面
				byteArrayOutputStream.write(buffer, 0, len);
			}
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		} finally {
			try {
				byteArrayOutputStream.close();
			} catch (IOException e) {
				e.printStackTrace();
				return null;
			}
		}

		// 得到数据后返回
		return byteArrayOutputStream.toByteArray();

	}
	

}
