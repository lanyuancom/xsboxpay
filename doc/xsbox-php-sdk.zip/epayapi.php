<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>小盒支付站点</title>
</head>
<body>
<?php
/**
* @Note  发起支付
* @param @pid            商户ID
* @param @name           商品名称
* @param @type           wxjs 微信JSAPI
* @param @money          金额（元）
* @param @out_trade_no   订单号
* @param @notify_url     异步通知地址
* @param @return_url     同步支付地址（支付成功后跳转的页面）
* @param @key            密钥
*/
function mp_pay($name,$money, $out_trade_no)
{
	$notify_url = "http://IP:端口/xsbox-php-sdk/notify_url.php";
	//需http://格式的完整路径，不能加?id=123这类自定义参数

	//暂不支持同步回调
	$return_url = "";
	
    $url = "http://【网关】/xsbox-pay/api/pay/subOrder";
	$mchNo = "【商户号】";
	$appSecret = "【密钥】";
	$appId = "【应用APPID】";
    $data = [
		"mchNo" 		=> $mchNo,
		"appSecret" 	=> $appSecret,
		"appId" 		=> $appId,
        'subject'       => $name,
        'amount'        => $money,
        'mchOrderNo' => $out_trade_no,
        'notifyUrl'   => $notify_url,
        'returnUrl'   => $return_url,
    ];
    $data = array_filter($data);
    ksort($data);
    $str1 = '';
    foreach ($data as $k => $v) {
        $str1 .= '&' . $k . "=" . $v;
    }
    //$sign = md5(trim($str1 . $key, '&'));
    //$data['sign']      = $sign;
    $data['is_wx_browser']      = '1'; // 不参与签名

    $headers = array('Content-Type: application/x-www-form-urlencoded');
    $curl = curl_init(); // 启动一个CURL会话
    curl_setopt($curl, CURLOPT_URL, $url); // 要访问的地址
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0); // 对认证证书来源的检查
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0); // 从证书中检查SSL加密算法是否存在
    curl_setopt($curl, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']); // 模拟用户使用的浏览器
    curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1); // 使用自动跳转
    curl_setopt($curl, CURLOPT_AUTOREFERER, 1); // 自动设置Referer
    curl_setopt($curl, CURLOPT_POST, 1); // 发送一个常规的Post请求
    curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data)); // Post提交的数据包
    curl_setopt($curl, CURLOPT_TIMEOUT, 30); // 设置超时限制防止死循环
    curl_setopt($curl, CURLOPT_HEADER, 0); // 显示返回的Header区域内容
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1); // 获取的信息以文件流的形式返回
    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
    $result = curl_exec($curl); // 执行操作
    if (curl_errno($curl)) {
        echo 'Errno'.curl_error($curl);//捕抓异常
    }
    curl_close($curl); // 关闭CURL会话
    $result = json_decode($result, true);
	$wxUrl = $result['data']['payUrl'];
	?>

        <script>

            window.location.href='<?php echo $wxUrl;?>';
        </script>
	<?php
}
/**************************请求参数**************************/

//商户订单号
$out_trade_no = $_POST['WIDout_trade_no'];
//商户网站订单系统中唯一订单号，必填

//商品名称
$name = $_POST['WIDsubject'];
//付款金额
$money = $_POST['WIDtotal_fee'];
$money = 100 * $money;
$money = (int)$money;
mp_pay($name,$money, $out_trade_no);
?>
</body>
</html>